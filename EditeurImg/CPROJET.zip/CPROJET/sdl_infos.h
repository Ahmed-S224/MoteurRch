#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <stdio.h>
#include <stdlib.h>

struct SDL_Window {
	const void *magic;
	Uint32 id;
	char *title;
	SDL_Surface *icon;
	int x, y;
	int w, h;
	SDL_Rect poswin;

	SDL_Window *prev;
	SDL_Window *next;
};
