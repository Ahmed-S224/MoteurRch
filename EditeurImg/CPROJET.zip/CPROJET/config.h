char *prompt(void){//renvoie l'ID utilisateur effectif du processus appelant.
      char *prompt="mon prompt>>";
         if(geteuid()==0){//si l'ID utilisateur du processus appelant vaut 0
	     prompt="#";
	 }
          
  return prompt;
}


static Alias aliases[] = {//tableau d'aliases utilisé dans commande.c
	
        {"syu", {"sudo", "pacman","-Syu",NULL, }},
        {"lla",	{"ls","-AFhl","--color=auto",NULL,}},
        {"la", {"ls","-AFh","--color=auto",NULL,}},

};
