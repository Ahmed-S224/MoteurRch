#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>

SDL_Texture *load(/*const char path[]*/char **args, SDL_Renderer *renderer);
