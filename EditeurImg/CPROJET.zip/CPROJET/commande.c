#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#define SUCCESS 1
#define FAILURE 0
#include "load.h"
#include <readline/readline.h>
#include <readline/history.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>



#define size 10000

static char* readLine(void);//Lire la commande que j'ecris
static char** splitLine(char *);//ligne de separation
static int launch(char **);//permettre de lancer la commande
static int execute(char **);//permmettre l'execution de la commande




const char *words[] = {"open"};



typedef struct {
	char *name;//nom de la commande
	char *buff[100]; 
}Alias;

typedef struct{ //structure pour le nom des commandes
   char *name;
   int (*buff)(char **);//buff represente la fonction
}function;



static char DEL[]=" \n\t\a\r";//Utile pour spliteLIne
static function functions[]={//tableau de commandes
//name      //commande
{ "open",load}
};

#include "config.h"

#define BUFSIZE 1000

 char *readLine(){//va lire la ligne inscrite
   FILE* fichier = NULL;
   fichier = fopen("history", "a");
   int bufsize = BUFSIZE;
   int pos = 0;
   char *buffer = malloc(sizeof(char) * bufsize);
   int c;
   if(!buffer){//erreur allocation
     fprintf(stderr, "mpsh : erreur d'alloc");
     exit(EXIT_FAILURE);
   }
    while (1){
     c = getchar();


     if(c == EOF){
       exit(EXIT_SUCCESS);
     }


     else if (c =='\n'){

       buffer[pos] = '\0';
       //ajouterHistorique(fichier,buffer);//on va ajouter dans l'historique 
       return buffer;

     }else{
       buffer[pos]=c;
     }

     pos++;

       if(pos >= bufsize){//en cas d'allocation memoire trop faible on réalloc
         bufsize +=BUFSIZE;
         buffer = realloc(buffer,bufsize);
       if(!buffer){//si erreur alors affiche message
         fprintf(stderr, "mpsh : erreur d'alloc\n");
         exit(EXIT_FAILURE);
       }
     }
   }

 }








char **splitLine(char *ligne){
	unsigned int curs_position=0;
	size_t BUFFER=80;
	size_t TAILLE_BUFFER=BUFFER;
	char *token;
	char **TOKEN= malloc(sizeof(char*)*BUFFER);//le token prendra l'espace du BUFFER
	
    if(!TOKEN){//si probleme d'allocation
	perror("Erreur d'allocation de memoire\n");
	exit(EXIT_FAILURE);
    }
    token = strtok(ligne, DEL);//Le mot obtenu sera obtenu grace au scindement de la ligne(1ére appel), TOKENS sera le delimiteur
	 while(token != NULL){//tant qu'on a une chaine de carractère
	      TOKEN[curs_position] = token;
	       curs_position++;
                   if(TAILLE_BUFFER<=curs_position){//Si la taille du buffer est inferieur ou egal à la position du mot on augmente la taille
		      TAILLE_BUFFER=TAILLE_BUFFER+BUFFER;
		      TOKEN=realloc(TOKEN, sizeof(char*)*TAILLE_BUFFER);//on va realloc le TOKEN avec la nouvelle taille
		       if(!TOKEN){//si probleme d'allocation
			perror("allocation error\n");
			 exit(EXIT_FAILURE);
		       }
		   }

	token = strtok(NULL, DEL);//le mot sera obtenu grace au scindement (chaque appel ultérieur fait pour analyser la même chaîne, str doit être NULL) 
	}
    TOKEN[curs_position]=NULL;
    return TOKEN;
}







int launch(char **args){//permettre de lancer la commande
 int status;
 pid_t pid; //initialisation de deux identifiant processus 
 pid_t pid2;
 pid=fork();//creer un processus 
  if(pid==0){//cas du processus fils-->ERREUR
    if(execvp(args[0],args)==-1){
	 perror("ERREUR");
     }
        exit(EXIT_FAILURE);
  }else if(pid<0){
	perror("ERREUR");
  }else{//cas du processus parent

    while(!WIFEXITED(status)&&!WIFSIGNALED(status)){//tant que le  processus fils ne s'est pas fini correctement
        pid2= waitpid(pid, &status, WUNTRACED);// L’appel système waitpid() suspend  l’exécution  du  processus  appelant jusqu’à  ce que pid change d’état puis renvoie l’identifiant du processus fils dont l’état a changé
    }
  }
   return SUCCESS;
}









int execute(char **args){
  int nombres_functions = sizeof(functions)/sizeof(functions[0]);//taille tableau
  int nombres_aliases = sizeof(aliases)/sizeof(aliases[0]);//tailles aliases 
    if(args[0]==NULL){//aucunes commande inscrite
	return SUCCESS;
    }

	int i;
	for(i = 0; i < nombres_aliases; i++){// Regarder dans notre tableau d'aliases
		if(strcmp(args[0], aliases[i].name) == 0){
		  return launch(aliases[i].buff);
		}
	}

	// Regarder dans notre tableau de fonctions
       for(i=0;i<nombres_functions; i++){
	   if(strcmp(args[0],functions[i].name) == 0){//si la ligne ecrite correspond bien a l'une des fonction de lal liste 
	      return(*(functions[i].buff))(args);//on retourne la fonction associé
	   }
       }


	return launch(args);
}






/*
// va generer le mot par completion
char *generateur(const char *ligne, int status)
{
    static int i, sizeoftxt;
    const char *name;
    if (!status){
      i=0;
      sizeoftxt=strlen(ligne);
    }
      while ((name = words[i])){
       i++;
        if(strncmp(name,ligne,sizeoftxt)==0)
           return strdup (name);
        }
     return ((char *) NULL);
}






//Fonction completion qui inclut readLIne
static char **my_completion (const char *text, int start){
    rl_completion_append_character = '\0';
    char **matches=(char **) NULL;
    if (start==0){
        matches=rl_completion_matches((char *) text, &generateur);
    }
    return matches;
}
*/


struct SDL_Window
{
    const void *magic;
    Uint32 id;
    char *title;
    SDL_Surface *icon;
    int x, y;
    int w, h;
    SDL_Rect poswin;

    SDL_Window *prev;
    SDL_Window *next;
};






int init(SDL_Window **window, SDL_Renderer **renderer, int w, int h)
{
    if(0 != SDL_Init(SDL_INIT_VIDEO))
    {
        fprintf(stderr, "Erreur SDL_Init : %s", SDL_GetError());
        return -1;
    }
    *window = SDL_CreateWindow("EDITEUR", 10, 20,w, h, SDL_WINDOW_RESIZABLE);
    if(!window)
    {
        fprintf(stderr, "Erreur SDL_CreateWindow : %s", SDL_GetError());
        return -1;
    }
    *renderer = SDL_CreateRenderer(*window, 0, SDL_RENDERER_ACCELERATED);
    if (!renderer)
    {
        fprintf(stderr, "Erreur SDL_CreateRenderer : %s", SDL_GetError());
        return -1;
    }
    return 0;
}





SDL_Texture *loadImage(const char path[], SDL_Renderer *renderer)
{
    SDL_Surface *tmp = NULL; 
    SDL_Texture *texture = NULL;
    tmp = SDL_LoadBMP(path);
    //SDL_SetColorKey(tmp, SDL_TRUE, SDL_MapRGB(tmp->format, 0, 0, 0));
    if(NULL == tmp)
    {
        fprintf(stderr, "Erreur SDL_LoadBMP : %s", SDL_GetError());
        return NULL;
    }
    texture = SDL_CreateTextureFromSurface(renderer, tmp);
    SDL_RenderCopy(renderer, texture, NULL, NULL);
    //texture = IMG_LoadTexture(renderer, path);
    SDL_FreeSurface(tmp);
    if(NULL == texture)
    {
        fprintf(stderr, "Erreur SDL_CreateTextureFromSurface : %s", SDL_GetError());
        return NULL;
    }
    return texture;
}







int setWindowColor(SDL_Renderer *renderer, SDL_Color color)
{
    if(SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a) < 0)
        return -1;
    if(SDL_RenderClear(renderer) < 0)
        return -1;
    return 0;  
}







SDL_Texture *degrade(SDL_Renderer *renderer)
{
    SDL_Texture *texture = NULL;
    SDL_PixelFormat *format;

    texture = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_STATIC, 1, 255); 
    Uint32 pixels[255] = {0};
    size_t i;
    format = SDL_AllocFormat(SDL_PIXELFORMAT_RGBA8888);
    for(i = 0; i < 255; i++)
        pixels[i] = SDL_MapRGBA(format, i, 0, 0, 255);
    SDL_UpdateTexture(texture, NULL, pixels, sizeof(Uint32) * 1);
    SDL_FreeFormat(format);
    return texture;
}








void wait2(SDL_Window * pWindow, SDL_Texture * image, SDL_Rect fonte, SDL_Renderer * renderer)
{
    SDL_Event event;
    SDL_Rect res;
    int fullscreen =0;
    int quit = 0;
    while (quit!=1) // Récupération des actions de l'utilisateur
{
    SDL_PollEvent(&event);
    switch(event.type)
    {
        case SDL_QUIT: // Clic sur la croix
            quit=1;
            break;
        case SDL_KEYUP: // Relâchement d'une touche
            if ( event.key.keysym.sym == SDLK_f ) // Touche f
            {
                // Alterne du mode plein écran au mode fenêtré
                if ( fullscreen == 0 )
                {
                    fullscreen = 1;
                    SDL_SetWindowFullscreen(pWindow,SDL_WINDOW_FULLSCREEN);
                }
                else if ( fullscreen == 1 )
                {
                    fullscreen = 0;
                    SDL_SetWindowFullscreen(pWindow,0);
                }
            }
            break;

        case SDL_MOUSEBUTTONUP:
             printf("%d %d\n", pWindow->x, pWindow->y);            
            pWindow ->poswin.x = event.motion.x ;           
            pWindow ->poswin.y = event.motion.y ;
            res = pWindow ->poswin;
            break; 
    }

    SDL_RenderCopy(renderer, image, &fonte, &res);
}
}








int main(int argc, char *argv[]) {   
/*	FILE* fichier=NULL;
	SDL_Window *window = NULL;
    	SDL_Renderer *renderer = NULL;
    	SDL_Texture *image, *image2 = NULL;
    	int statut = EXIT_FAILURE;
       		if(0 != init(&window, &renderer, 1000, 750)) 
       			goto Quit;
   				window ->poswin.x = 0;
    				window ->poswin.y = 0;
    				SDL_Rect fonte = {0,0,1000,750};
				SDL_Rect fonte2 = {0,0,30,41};
				SDL_Rect destino = {500,0,800,600};
				SDL_Rect destino2 = {0,0,30,41};
				image = loadImage("tiger_snow.bmp", renderer);
    				if(NULL == image || NULL == image2)
    				    goto Quit;
					statut = EXIT_SUCCESS;
    					SDL_RenderPresent(renderer);
 
    					SDL_Event event;
    					int fullscreen =0;
    					int quit = 0;
    						


						while (quit!=1){
    							SDL_PollEvent(&event);
    							switch(event.type){
        							case SDL_QUIT: // Clic sur la croix
            							quit=1;
            							break;
        							case SDL_KEYUP: // Relâchement d'une touche
            								if ( event.key.keysym.sym == SDLK_f ){//touche f
                							// Alterne du mode plein écran au mode fenêtré
                							if ( fullscreen == 0 ){
                    								fullscreen = 1;
                    								SDL_SetWindowFullscreen(window,SDL_WINDOW_FULLSCREEN);
                							}
                							else if ( fullscreen == 1 ){
                    								fullscreen = 0;
                    								SDL_SetWindowFullscreen(window,0);
                							}
            								}
            								break;

        							case SDL_MOUSEBUTTONUP:
								     printf("%d %d\n", window->x, window->y);            
								destino.x = event.motion.x ;              
								    destino.y = event.motion.y ;
								    //res = pWindow ->poswin;
								    SDL_RenderCopy(renderer, image, &fonte, &destino);
								    SDL_RenderPresent(renderer);

							       SDL_RenderCopy(renderer, image2, &fonte2, &destino2);
								    break; 
    							}

						}
    
								SDL_RenderPresent(renderer);    
    								Quit:
						    if(NULL != renderer)
							SDL_DestroyRenderer(renderer);
						    if(NULL != window)
							SDL_DestroyWindow(window);
						    
						    SDL_Quit();
						    return statut;
	*/
char **args;
char *ligne;
int status;
while(status){
  printf(prompt());//afficher l'invit de commande
  ligne=readLine();
  args=splitLine(ligne);//retourner chaque fragement de mot de la ligne à scinder
  status=execute(args);//retourn le status de la commande à éxecuter
  free(ligne);
  free(args);
}
return SUCCESS;
}
