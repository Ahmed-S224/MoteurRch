#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include "load.h"
#include "sdl_infos.h"

SDL_Texture *load(/*const char path[]*/char **args, SDL_Renderer *renderer){
	SDL_Surface *tmp = NULL;
	SDL_Texture *texture = NULL;
	tmp = SDL_LoadBMP(/*path*/args);
	if (NULL == tmp) {
		fprintf(stderr, "Erreur SDL_LoadBMP : %s", SDL_GetError());
		return NULL;
	}
	texture = SDL_CreateTextureFromSurface(renderer, tmp);
	SDL_RenderCopy(renderer, texture, NULL, NULL);
	SDL_FreeSurface(tmp);
	if (NULL == texture) {
		fprintf(stderr, "Erreur SDL_CreateTextureFromSurface : %s",
				SDL_GetError());
		return NULL;
	}
	return texture;
}

